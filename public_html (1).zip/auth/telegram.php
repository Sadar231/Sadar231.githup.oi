<?php
$id_telegram = "6486748064";
$id_botTele  = "7377378566:AAE7Zh4qW4yVv0T7m-lXA67E5BnzsuMuCMM";
?>