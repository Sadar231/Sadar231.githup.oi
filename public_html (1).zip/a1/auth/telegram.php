<?php
$id_telegram = "         ";
$id_botTele  = "                  ";
?>